
export let searchBtn = document.getElementById('searchBtn');
export let searchInput = document.getElementById('searchInput');
export let searchResultContainer = document.getElementById('searchResult');
export let recipeDetailsContainer = document.getElementById('recipeDetails');
